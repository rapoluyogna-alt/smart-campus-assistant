import { CampusAssistant } from "@/components/campus-assistant"

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <CampusAssistant />
    </main>
  )
}
